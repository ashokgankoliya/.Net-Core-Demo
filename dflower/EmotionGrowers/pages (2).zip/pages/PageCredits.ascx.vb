﻿
Partial Class pages_PageCredits
    Inherits System.Web.UI.UserControl

End Class
