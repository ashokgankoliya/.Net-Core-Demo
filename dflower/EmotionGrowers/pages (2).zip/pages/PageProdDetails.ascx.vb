﻿
Partial Class pages_PageProdDetails
    Inherits System.Web.UI.UserControl

End Class
