﻿
Partial Class pages_PagePictures
    Inherits System.Web.UI.UserControl

End Class
