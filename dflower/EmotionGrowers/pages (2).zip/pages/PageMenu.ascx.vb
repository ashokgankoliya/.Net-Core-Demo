﻿
Partial Class pages_PageMenu
    Inherits System.Web.UI.UserControl

End Class
