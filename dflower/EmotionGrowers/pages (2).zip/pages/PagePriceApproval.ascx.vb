﻿
Partial Class pages_PagePriceApproval
    Inherits System.Web.UI.UserControl

End Class
