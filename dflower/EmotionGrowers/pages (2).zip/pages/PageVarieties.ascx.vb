﻿
Partial Class pages_PageVarieties
    Inherits System.Web.UI.UserControl

End Class
