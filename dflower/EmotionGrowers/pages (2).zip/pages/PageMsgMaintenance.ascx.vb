﻿
Partial Class pages_PageMsgMaintenance
    Inherits System.Web.UI.UserControl

End Class
