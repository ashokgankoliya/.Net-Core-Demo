﻿
Partial Class pages_PageProdCategories
    Inherits System.Web.UI.UserControl

End Class
