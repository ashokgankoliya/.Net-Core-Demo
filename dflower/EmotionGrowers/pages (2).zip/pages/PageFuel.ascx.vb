﻿
Partial Class pages_PageFuel
    Inherits System.Web.UI.UserControl

End Class
