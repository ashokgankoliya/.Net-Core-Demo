﻿
Partial Class pages_PageDynamicGrid
    Inherits System.Web.UI.UserControl

End Class
