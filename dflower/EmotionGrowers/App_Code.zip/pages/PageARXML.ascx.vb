﻿
Partial Class pages_PageARXML
    Inherits System.Web.UI.UserControl

End Class
