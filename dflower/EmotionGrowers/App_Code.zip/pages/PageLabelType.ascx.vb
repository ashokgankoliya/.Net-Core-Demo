﻿
Partial Class pages_PageLabelType
    Inherits System.Web.UI.UserControl

End Class
