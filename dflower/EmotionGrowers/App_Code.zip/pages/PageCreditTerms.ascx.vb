﻿
Partial Class pages_PageCreditTerms
    Inherits System.Web.UI.UserControl

End Class
