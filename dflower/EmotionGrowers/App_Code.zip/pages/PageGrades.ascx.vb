﻿
Partial Class pages_PageGrades
    Inherits System.Web.UI.UserControl

End Class
