﻿
Partial Class pages_PageEmail
    Inherits System.Web.UI.UserControl
    'Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
    '    Dim LoginUserDetails As New User
    '    If (Not Session("LoginUserDetails") Is Nothing) Then
    '        LoginUserDetails = Session("LoginUserDetails")
    '        divLoginUserName.InnerText = LoginUserDetails.Name
    '    End If
    'End Sub
End Class
