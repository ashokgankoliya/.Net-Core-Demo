﻿
Partial Class pages_PageCreditCode
    Inherits System.Web.UI.UserControl

End Class
