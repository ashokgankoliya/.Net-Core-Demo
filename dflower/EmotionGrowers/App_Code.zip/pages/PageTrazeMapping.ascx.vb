﻿
Partial Class pages_PageTrazeMapping
    Inherits System.Web.UI.UserControl

End Class
