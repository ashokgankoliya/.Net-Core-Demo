﻿
Partial Class pages_PageCountry
    Inherits System.Web.UI.UserControl

End Class
