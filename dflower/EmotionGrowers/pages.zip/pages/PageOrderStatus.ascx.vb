﻿
Partial Class pages_PageOrderStatus
    Inherits System.Web.UI.UserControl

End Class
