﻿
Partial Class pages_PageFeatures
    Inherits System.Web.UI.UserControl

End Class
