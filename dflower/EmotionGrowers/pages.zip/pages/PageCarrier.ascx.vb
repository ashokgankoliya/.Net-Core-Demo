﻿
Partial Class pages_PageCarrier
    Inherits System.Web.UI.UserControl

End Class
