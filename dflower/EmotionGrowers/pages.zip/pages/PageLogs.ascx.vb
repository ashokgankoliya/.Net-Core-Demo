﻿
Partial Class pages_PageLogs
    Inherits System.Web.UI.UserControl

End Class
