﻿
Partial Class pages_PageOrderTypes
    Inherits System.Web.UI.UserControl

End Class
