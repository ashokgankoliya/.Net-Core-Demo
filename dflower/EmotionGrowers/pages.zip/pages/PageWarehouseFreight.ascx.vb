﻿
Partial Class pages_PageWarehouseFreight
    Inherits System.Web.UI.UserControl

End Class
