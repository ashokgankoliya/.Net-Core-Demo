﻿
Partial Class pages_PostReturnsByCustomer
    Inherits System.Web.UI.UserControl

End Class
