﻿
Partial Class pages_PageSalesManCode
    Inherits System.Web.UI.UserControl

End Class
