﻿
Partial Class pages_PageWarehouse
    Inherits System.Web.UI.UserControl

End Class
