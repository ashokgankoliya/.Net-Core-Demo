﻿
Partial Class pages_PageEmails
    Inherits System.Web.UI.UserControl

End Class
