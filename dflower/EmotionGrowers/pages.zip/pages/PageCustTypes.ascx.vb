﻿
Partial Class pages_PageCustTypes
    Inherits System.Web.UI.UserControl

End Class
