﻿
Partial Class pages_PageWebPermission
    Inherits System.Web.UI.UserControl

End Class
